/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.edu.ifsc.model;

/**
 *
 * @author PC
 */
public class CalculoImc {
    
    private String nome;
    private int idade;
    private String sexo;  
    private double altura;
    private double peso;

    public CalculoImc() {
    }

    public CalculoImc(String nome, int idade, String sexo, double altura, double peso) {
        this.nome = nome;
        this.idade = idade;
        this.sexo = sexo;
        this.altura = altura;
        this.peso = peso;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    
    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public double getAltura() {
        return altura;
    }

    public void setAltura(double altura) {
        this.altura = altura;
    }
    
    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    private double calcularIMC() {
        return  peso / (Math.pow(altura, 2));
    }
    
    private String classificarIMC() {
        double imc = calcularIMC();
        if(imc < 18.5) {
            return "Abaixo do peso";
        }else if (imc < 24.9) {
            return "Peso Adequado";
        }else if (imc < 29.9) {
            return "Sobrepeso";
        }else if (imc < 34.9) {
            return "Obesidade de grau 1";
        }else if (imc < 39.9) {
            return "Obesidade de grau 2";
        }else {
            return "Obesidade Extrema";
        }
    } 
    
    public String getDados() {
        StringBuilder sb = new StringBuilder();
        sb.append("**** Dados do IMC calculado ****").append("\n");
        sb.append("================================").append("\n");
        sb.append("Nome....: ").append(nome).append("\n");
        sb.append("Idade...: ").append(idade).append("\n");
        sb.append("Sexo....: ").append(sexo).append("\n");
        sb.append("Altura..: ").append(altura).append("\n");
        sb.append("Peso....: ").append(peso).append("\n\n");
        sb.append("IMC.....: ").append(calcularIMC()).append("\n");
        sb.append("Classe..: ").append(classificarIMC()).append("\n");
        sb.append("===============================").append("\n");
        return sb.toString();
    }
}
